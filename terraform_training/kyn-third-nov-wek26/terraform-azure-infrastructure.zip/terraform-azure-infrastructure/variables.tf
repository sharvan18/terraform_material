variable "resource_group_name" {
  description = "Base name of the Azure resource group."
  type        = string
  default     = "rg-kyn-gopal"
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "eastus"
}

variable "environment" {
  description = "Deployment environment."
  type        = string
  default     = "dev"
}

variable "business_unit" {
  description = "Business unit used in resource naming."
  type        = string
  default     = "it"
}

variable "project_name" {
  description = "Project tag value."
  type        = string
  default     = "kyn"
}

variable "vnet_name" {
  description = "Base name of the virtual network."
  type        = string
  default     = "kyn-vnet"
}

variable "vnet_address_space" {
  description = "VNet address spaces."
  type        = list(string)
  default     = ["10.0.0.0/16"]
}

variable "subnets" {
  description = "Subnet and VM placement configuration, keyed by instance name."
  type = map(object({
    name              = string
    address_prefix    = list(string)
    availability_zone = string
  }))
}

variable "admin_username" {
  description = "Linux VM administrator username."
  type        = string
  default     = "azureuser"
}

variable "ssh_public_key_path" {
  description = "Path to the SSH public key on the machine running Terraform."
  type        = string
  default     = "./ssh-keys/terraform-azure.pem.pub"
}

variable "vm_size" {
  description = "Azure Linux VM size."
  type        = string
  default     = "Standard_F2"
}

variable "nsg_rules" {
  description = "Inbound NSG rules. Restrict SSH source_address_prefix to your public IP/CIDR."
  type = list(object({
    name                       = string
    priority                   = number
    destination_port_range     = string
    source_address_prefix      = string
  }))
  default = [
    {
      name                   = "Allow-SSH"
      priority               = 110
      destination_port_range = "22"
      source_address_prefix  = "0.0.0.0/0"
    },
    {
      name                   = "Allow-HTTP"
      priority               = 120
      destination_port_range = "80"
      source_address_prefix  = "*"
    },
    {
      name                   = "Allow-HTTPS"
      priority               = 130
      destination_port_range = "443"
      source_address_prefix  = "*"
    }
  ]
}
