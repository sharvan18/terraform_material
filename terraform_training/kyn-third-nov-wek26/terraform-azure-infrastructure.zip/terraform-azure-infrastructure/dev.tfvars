resource_group_name = "rg-kyn-gopal"
location            = "eastus"
environment          = "dev"
business_unit        = "sap"
project_name         = "kyn"

vnet_name          = "kyn-vnet"
vnet_address_space = ["172.16.0.0/16"]

subnets = {
  subnet1 = {
    name              = "web-subnet-az1"
    address_prefix    = ["172.16.1.0/24"]
    availability_zone = "1"
  }
}

# Replace this with the path to your own public key.
ssh_public_key_path = "./ssh-keys/terraform-azure.pem.pub"

# IMPORTANT: Replace 203.0.113.10/32 with your actual public IP/CIDR.
nsg_rules = [
  {
    name                   = "Allow-SSH-Admin"
    priority               = 110
    destination_port_range = "22"
    source_address_prefix  = "203.0.113.10/32"
  },
  {
    name                   = "Allow-HTTP"
    priority               = 120
    destination_port_range = "80"
    source_address_prefix  = "*"
  },
  {
    name                   = "Allow-HTTPS"
    priority               = 130
    destination_port_range = "443"
    source_address_prefix  = "*"
  }
]

