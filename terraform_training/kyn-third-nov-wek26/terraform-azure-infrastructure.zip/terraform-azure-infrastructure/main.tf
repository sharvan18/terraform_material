resource "azurerm_resource_group" "this" {
  name     = "${local.resource_name_prefix}-${var.resource_group_name}"
  location = var.location
  tags     = local.project_tags
}

module "networking" {
  source              = "./modules/networking"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  name_prefix         = local.resource_name_prefix
  vnet_name           = var.vnet_name
  vnet_address_space  = var.vnet_address_space
  subnets             = var.subnets
  tags                = local.project_tags
}

module "security_group" {
  source              = "./modules/security-group"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  name_prefix         = local.resource_name_prefix
  subnet_ids          = module.networking.subnet_ids
  rules               = var.nsg_rules
  tags                = local.project_tags
}

module "compute" {
  source              = "./modules/compute"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  name_prefix         = local.resource_name_prefix
  subnets             = var.subnets
  nic_ids             = module.networking.nic_ids
  admin_username      = var.admin_username
  ssh_public_key      = file(var.ssh_public_key_path)
  vm_size             = var.vm_size
  tags                = local.project_tags

  depends_on = [module.security_group]
}

module "load_balancer" {
  source              = "./modules/load-balancer"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  name_prefix         = local.resource_name_prefix
  nic_ids             = module.networking.nic_ids
  tags                = local.project_tags
}
