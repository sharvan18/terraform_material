variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "vnet_name" { type = string }
variable "vnet_address_space" { type = list(string) }
variable "subnets" {
  type = map(object({
    name              = string
    address_prefix    = list(string)
    availability_zone = string
  }))
}
variable "tags" { type = map(string) }
