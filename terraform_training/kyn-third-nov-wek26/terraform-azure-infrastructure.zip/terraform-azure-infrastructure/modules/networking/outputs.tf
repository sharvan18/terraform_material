output "vnet_id" {
  value = azurerm_virtual_network.this.id
}

output "subnet_ids" {
  value = { for key, subnet in azurerm_subnet.this : key => subnet.id }
}

output "nic_ids" {
  value = { for key, nic in azurerm_network_interface.this : key => nic.id }
}
