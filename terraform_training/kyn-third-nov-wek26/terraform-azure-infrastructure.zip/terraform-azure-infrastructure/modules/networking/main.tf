resource "azurerm_virtual_network" "this" {
  name                = "${var.name_prefix}-${var.vnet_name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = var.vnet_address_space
  tags                = var.tags
}

resource "azurerm_subnet" "this" {
  for_each             = var.subnets
  name                 = each.value.name
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = each.value.address_prefix
}

resource "azurerm_network_interface" "this" {
  for_each            = var.subnets
  name                = "${var.name_prefix}-nic-${each.key}"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = azurerm_subnet.this[each.key].id
    private_ip_address_allocation = "Dynamic"
  }

  tags = var.tags
}
