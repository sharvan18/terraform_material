variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "subnet_ids" { type = map(string) }
variable "tags" { type = map(string) }
variable "rules" {
  type = list(object({
    name                   = string
    priority               = number
    destination_port_range = string
    source_address_prefix  = string
  }))
}
