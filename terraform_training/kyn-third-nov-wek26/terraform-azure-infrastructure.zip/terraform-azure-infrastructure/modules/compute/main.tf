resource "azurerm_linux_virtual_machine" "this" {
  for_each            = var.subnets
  name                = "${var.name_prefix}-vm-${each.key}"
  resource_group_name = var.resource_group_name
  location            = var.location
  size                = var.vm_size
  zone                = each.value.availability_zone
  admin_username      = var.admin_username
  network_interface_ids = [
    var.nic_ids[each.key]
  ]

  disable_password_authentication = true

  admin_ssh_key {
    username   = var.admin_username
    public_key = trimspace(var.ssh_public_key)
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  custom_data = base64encode(file("${path.module}/app.sh"))
  tags        = var.tags
}
