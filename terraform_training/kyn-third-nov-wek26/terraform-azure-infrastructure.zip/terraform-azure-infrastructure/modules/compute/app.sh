#!/bin/bash
set -eux

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nginx lsb-release

HOSTNAME_VALUE="$(hostname)"
PRIVATE_IP="$(hostname -I | awk '{print $1}')"
OS_NAME="$(lsb_release -ds)"

cat > /var/www/html/index.html <<EOF
<!DOCTYPE html>
<html>
<head>
  <title>Terraform Azure Demo</title>
</head>
<body>
  <h1>Hello from Terraform on Azure!</h1>
  <h2>Ubuntu VM + Nginx</h2>
  <p><strong>Server deployed using reusable Terraform modules.</strong></p>
  <hr>
  <h3>Server Information</h3>
  <p><strong>Hostname:</strong> ${HOSTNAME_VALUE}</p>
  <p><strong>Private IP:</strong> ${PRIVATE_IP}</p>
  <p><strong>Operating System:</strong> ${OS_NAME}</p>
  <p><strong>Web Server:</strong> Nginx</p>
</body>
</html>
EOF

systemctl enable nginx
systemctl restart nginx
