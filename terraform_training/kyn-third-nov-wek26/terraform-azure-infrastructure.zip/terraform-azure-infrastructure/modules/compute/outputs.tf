output "vm_ids" {
  value = { for key, vm in azurerm_linux_virtual_machine.this : key => vm.id }
}

output "private_ips" {
  value = { for key, nic_id in var.nic_ids : key => azurerm_linux_virtual_machine.this[key].private_ip_address }
}
