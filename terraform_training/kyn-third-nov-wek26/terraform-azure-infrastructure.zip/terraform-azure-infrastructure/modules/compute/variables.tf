variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "admin_username" { type = string }
variable "ssh_public_key" { type = string }
variable "vm_size" { type = string }
variable "nic_ids" { type = map(string) }
variable "tags" { type = map(string) }
variable "subnets" {
  type = map(object({
    name              = string
    address_prefix    = list(string)
    availability_zone = string
  }))
}
