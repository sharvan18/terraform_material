variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name_prefix" { type = string }
variable "nic_ids" { type = map(string) }
variable "tags" { type = map(string) }
