# Reusable Azure Infrastructure with Terraform Modules

This repository provisions an Azure resource group, VNet, subnets, NICs, NSG rules,
Ubuntu Linux VMs, a Standard public Load Balancer, .

## Architecture

- `modules/networking`: VNet, subnets and network interfaces.
- `modules/security-group`: NSG, inbound rules and subnet associations.
- `modules/compute`: Ubuntu Linux VMs, SSH authentication and Nginx cloud-init.
- `modules/load-balancer`: Standard public IP, Load Balancer, backend pool, probe,
  HTTP rule and NIC backend associations.
- Root configuration: resource group, module wiring, environment variables and outputs.

## Prerequisites

1. Terraform CLI 1.5 or later.
2. Azure CLI.
3. An Azure subscription with permission to create the resources.
4. An SSH key pair. The public key is passed to the VMs; never commit a private key.
5. A globally unique Storage Account name if `enable_storage = true`.

Authenticate:

```bash
az login
az account set --subscription "<SUBSCRIPTION_ID>"
az account show
```

Create an SSH key pair if required:

```bash
mkdir -p ssh-keys
ssh-keygen -t ed25519 -f ssh-keys/terraform-azure.pem -C "terraform-azure"
```

The public key path in the example is `ssh-keys/terraform-azure.pem.pub`.
Keep the private key out of Git.

## Deploy from this repository

Review `dev.tfvars`. Replace `203.0.113.10/32` with your real administrator public
IP/CIDR. This example deliberately scopes SSH access; do not expose port 22 to the
whole internet in production.

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan -var-file="dev.tfvars" -out="dev.tfplan"
terraform apply "dev.tfplan"
```

Get outputs:

```bash
terraform output
terraform output -raw load_balancer_public_ip
```

Open `http://<LOAD_BALANCER_PUBLIC_IP>` in a browser after the VMs finish bootstrapping.

Destroy only when you intend to remove the resources:

```bash
terraform plan -destroy -var-file="dev.tfvars"
terraform destroy -var-file="dev.tfvars"
```

## Deploy production configuration

```bash
terraform plan -var-file="prod.tfvars" -out="prod.tfplan"
terraform apply "prod.tfplan"
```

Use a separate state key/workspace or, preferably, a separate backend state for each
environment. Do not point dev and prod at the same state file.

## Consume this repository as a local module

In another Terraform project:

```hcl
module "azure_platform" {
  source = "git::https://github.com/<YOUR_GITHUB_USERNAME>/terraform-azure-infrastructure.git?ref=v1.0.0"

  resource_group_name = "rg-app-dev"
  location            = "eastus"
  environment         = "dev"
  business_unit       = "app"
  project_name        = "my-app"

  vnet_name          = "app-vnet"
  vnet_address_space = ["10.50.0.0/16"]

  subnets = {
    web1 = {
      name              = "web-subnet-1"
      address_prefix    = ["10.50.1.0/24"]
      availability_zone = "1"
    }
    web2 = {
      name              = "web-subnet-2"
      address_prefix    = ["10.50.2.0/24"]
      availability_zone = "2"
    }
  }

  ssh_public_key_path = "./ssh-keys/id_ed25519.pub"
  nsg_rules = [
    {
      name                   = "Allow-SSH-Admin"
      priority               = 110
      destination_port_range = "22"
      source_address_prefix  = "203.0.113.10/32"
    },
    {
      name                   = "Allow-HTTP"
      priority               = 120
      destination_port_range = "80"
      source_address_prefix  = "*"
    }
  ]

  enable_storage         = false
  storage_account_name   = "replacewithuniqueaccount"
  storage_container_name = "appdata"
}

output "app_load_balancer_ip" {
  value = module.azure_platform.load_balancer_public_ip
}
```

The consuming project must also configure the `azurerm` provider and authenticate
to Azure. The `ssh_public_key_path` is evaluated relative to the root module that
calls this module. Run `terraform init` in the consuming project to download it.

## Publish to GitHub

Create an empty GitHub repository named `terraform-azure-infrastructure`, then run
these commands from this project directory:

```bash
git init
git add .
git commit -m "Initial reusable Azure Terraform modules"
git branch -M main
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/terraform-azure-infrastructure.git
git push -u origin main
```

Create a version tag after validating the code:

```bash
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

Use the tag in module sources (`?ref=v1.0.0`) so consumers get a predictable version.

## Azure Storage remote state (optional)

The application Storage module has been removed from this project. If you choose to
use an Azure Storage Account solely as a remote Terraform state backend, that backend
is separate from the infrastructure modules and must already exist before `terraform init`.
Create the backend account and container separately, then add this block to the root configuration:

```hcl
terraform {
  backend "azurerm" {
    resource_group_name  = "gopal-terraform-storage"
    storage_account_name = "terraformstoragegopal"
    container_name       = "tfstate"
    key                  = "kyn-dev.tfstate"
  }
}
```

For production, use a different key such as `kyn-prod.tfstate`, and protect the
state container with appropriate access controls, versioning/soft delete and
least-privilege identity permissions. Never commit state files or credentials.

## Important implementation notes

- Azure subnet resources do not have an availability-zone property. The
  `availability_zone` value is used for VM placement in the compute module.
- The original `173.16.0.0/16` address range is not an RFC1918 private range.
  Use private ranges such as `10.0.0.0/8`, `172.16.0.0/12`, or `192.168.0.0/16`.
- `Standard_F2` availability depends on region, subscription quota and zone support.
  Change `vm_size` or zones if Azure reports a capacity/quota error.
- The Nginx page displays hostname, private IP and Ubuntu OS details. The VM cloud-init
  script runs on first boot.
- The NSG example includes SSH, HTTP and HTTPS. Add only the ports your workload needs.
- The load balancer backend association uses each NIC's `internal` IP configuration.
- This sample is a reusable teaching/reference module, not a complete hardened
  enterprise landing zone. Consider private VMs, Bastion, TLS termination, WAF,
  managed identities, monitoring, backups, and policy controls for production.
