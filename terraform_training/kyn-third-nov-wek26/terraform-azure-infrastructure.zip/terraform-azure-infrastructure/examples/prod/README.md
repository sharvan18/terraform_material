# Production example

Run Terraform from the repository root using `prod.tfvars`.
Use a dedicated production backend state and replace all example names, SSH source
CIDRs, and storage account names before deployment.
