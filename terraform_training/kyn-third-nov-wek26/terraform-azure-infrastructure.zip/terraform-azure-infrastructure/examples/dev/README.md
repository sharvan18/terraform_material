# Development example

Run Terraform from the repository root using `dev.tfvars`:

```bash
terraform init
terraform plan -var-file="dev.tfvars"
terraform apply -var-file="dev.tfvars"
```
