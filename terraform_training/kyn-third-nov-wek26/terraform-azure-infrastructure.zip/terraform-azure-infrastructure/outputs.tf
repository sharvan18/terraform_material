output "resource_group_name" {
  description = "Created resource group."
  value       = azurerm_resource_group.this.name
}

output "location" {
  description = "Deployment region."
  value       = azurerm_resource_group.this.location
}

output "vnet_id" {
  description = "Virtual network ID."
  value       = module.networking.vnet_id
}

output "subnet_ids" {
  description = "Subnet IDs keyed by subnet map key."
  value       = module.networking.subnet_ids
}

output "vm_private_ips" {
  description = "Private IP addresses keyed by VM map key."
  value       = module.compute.private_ips
}

output "load_balancer_public_ip" {
  description = "Public frontend IP address of the Azure Load Balancer."
  value       = module.load_balancer.public_ip_address
}

output "load_balancer_fqdn" {
  description = "FQDN is not configured; use the public IP output."
  value       = null
}
