locals {
  resource_name_prefix = "${var.environment}-${var.business_unit}"

  project_tags = {
    environment   = var.environment
    business_unit = var.business_unit
    Project       = var.project_name
    managed_by    = "Terraform"
  }
}
